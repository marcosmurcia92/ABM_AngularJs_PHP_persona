<?php
include_once '../vendor/autoload.php';
use \Firebase\JWT\JWT;


$ClaveDeEncriptacion = "estaeslaclave";
$token["usuario"] = "unUsuario";
$token["perfil"] = "admin";
$token["iat"] = time();
$token["exp"] = time()+20;

$jwt = JWT::encode($token, $ClaveDeEncriptacion);

$ArrayConToken["ElNombreDelToken"] = $jwt;

echo json_encode($ArrayConToken);

?>