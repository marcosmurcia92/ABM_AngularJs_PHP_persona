# ABM_AngularJs_PHP_persona

Ejemplo de la carga de datos usando Angularjs y PHP.<br>
 **Primera parte:**<br>
 1.
En este ejemplo vemos la comparación entre las archivos con PHP incrustado y los HTML que solo tienen la VISTA.
<br>a.Concentramos nuestro trabajo en entender el binding y los tag  **ng-app** y **ng-controler**

