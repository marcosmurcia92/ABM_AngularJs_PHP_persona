<html>
<head>
	<title>Ejemplos de ABM - con archivo de texto</title>
	  
		<!--?php require_once"partes/referencias.php" ;/**/?-->
		<!--final de Estilos-->    

      <!--script type="text/javascript" src="./bower_components/jquery/dist/jquery.js"></script-->
       	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="http://www.octavio.com.ar/favicon.ico">
	<link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link rel="stylesheet" type="text/css" href="css/animacion.css">
</head>
<body>
	<!--?php		
		require_once"partes/barraDeMenu.php";
	 ?-->
	  <div class="container">

	  	  <div class="page-header " >
              <ul class="nav nav-tabs">
		         <li role="presentation"><a href="#/inicio">Inicio</a></li>
		         <li role="presentation"><a href="formAlta.php">Alta</a></li>
		         <li role="presentation"><a href="formGrilla.php">Grilla</a></li>
		         <h1>ABM - Con Angular y PHP Versión 1.0.1</h1>      
		      </ul>
            </div>
		           
					<div class="CajaInicio animated bounceInRight">
							<h1>PERSONAS</h1>
						
							<form id="FormIngreso">
 										
									    <a href="formAlta.php" class="list-group-item  list-group-item list-group-item-info">
									      <h4 class="list-group-item-heading">Alta de Personas</h4>
									    </a>
										
										<a href="formGrilla.php" class="list-group-item  list-group-item list-group-item-info">
									      <h4 class="list-group-item-heading">Grilla de Personas</h4>
									    </a>
									
									  </div>
									
							</form>
						</div>
		</div>
</body>
</html>